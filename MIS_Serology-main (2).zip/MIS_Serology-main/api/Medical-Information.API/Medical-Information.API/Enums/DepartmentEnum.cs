﻿namespace Medical_Information.API.Enums
{
    public enum Department
    {
        Chemistry,
        Serology,
        Blood_Bank,
        Hematology,
        Microbiology,
        Molecular,
        Urinalysis,
    }
}
