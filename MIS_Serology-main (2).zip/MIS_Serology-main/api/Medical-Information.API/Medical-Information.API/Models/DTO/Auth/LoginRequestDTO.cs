﻿using System.ComponentModel.DataAnnotations;

namespace Medical_Information.API.Models.DTO.Auth
{
    public class LoginByUsernameRequestDTO
    {
        [Required]
        public string Username { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }

    public class LoginByEmailRequestDTO
    {
        [Required]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
